#!/usr/bin/env bash
set -euo pipefail

echo "[n8n] Derrubando ambiente..."
docker compose down
